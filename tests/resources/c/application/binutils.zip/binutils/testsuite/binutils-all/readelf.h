ELF Header:
  Magic:   7f 45 4c 46 0[12] 0[12] 01 .. .. 00 00 00 00 00 00 00 
  Class:                             ELF[36][24]
  Data:                              2's complement,.* endian
  Version:                           1 \(current\)
  OS/ABI:                            .*
  ABI Version:                       .*
  Type:                              REL \(Relocatable file\)
  Machine:                           .*
  Version:                           0x1
  Entry point address:               (0x)?0
  Start of program headers:          0 \(bytes into file\)
  Start of section headers:          .* \(bytes into file\)
  Flags:                             .*
  Size of this header:               .* \(bytes\)
  Size of program headers:           0 \(bytes\)
  Number of program headers:         0
  Size of section headers:           .* \(bytes\)
  Number of section headers:         .*
  Section header string table index: .*
