/*** version.c -- version number for binutils.
     They all change in lockstep -- it's easier that way
*/

char *program_version = VERSION;
