/* Linked with objcopy.o to flag that this program is 'strip' (not
   'objcopy'). */

int is_strip = 1;
